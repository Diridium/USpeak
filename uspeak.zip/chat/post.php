<?php
session_start();
$sess = $_SESSION['login'];
include "../connect.php";
// php qui envoit le message écrit par l'utilisateur à une bdd sql

	$currentChannel = $_GET['channel'];
	$idCurrentChannel = $connect->query("SELECT ID FROM channels WHERE NOM = '$currentChannel'");
	$idCurrentChannel = $idCurrentChannel->fetch();
	$idCurrentChannel = $idCurrentChannel['ID'];


	// Insertion du message à l'aide d'une requête préparée
	$mess = $_POST['message'];
	if ($mess == '') {header('Location: /chat/');} else {
		$mess = str_replace("'",'"', $mess);
		$insertMess = $connect->query("INSERT INTO minichat(MESSAGES, ID_USER, ID_CHANNEL) VALUE('$mess', '$sess', '$idCurrentChannel')");
		$insertMess->closeCursor();
		// Redirection du visiteur vers la page du minichat
		header("Location: only_chat.php?channel=$currentChannel");
	}
?>