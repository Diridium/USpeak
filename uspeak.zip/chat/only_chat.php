<?php
session_start();
if (!isset($_SESSION['login'])) {header('Location: /');}
include "../connect.php";

if (isset($_GET['channel'])) {
	$currentChannel = $_GET['channel'];
}
?>

<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8">
        <title>Mini-chat</title>
		<link rel="stylesheet" type="text/css" href="/style/template.css">
		<link rel="stylesheet" type="text/css" href="/style/chat.css">
    	<link rel="icon" type="image/png" href="/images/favicon.ico">
	</head>
    <body>
    <?php
			
			$reponse = $connect->query("SELECT u.PSEUDO, m.MESSAGES, m.DATE_MESSAGE, u.PDP FROM minichat m JOIN user u ON u.ID = m.ID_USER JOIN channels c ON c.ID = m.ID_CHANNEL WHERE '$currentChannel' = c.NOM ORDER BY m.DATE_MESSAGE DESC");
			?>
			
			<div class="fil">
			<?php 
			// Affichage de chaque message (message protégé par htmlspecialchars)
			while ($donnees = $reponse->fetch()) { 
				if ($donnees['PSEUDO'] == $_SESSION['pseudo']) {
					echo '<div class="conv-own">';
				} else {echo '<div class="conversation">';}
				?>
					<div class="pseudo">
					<img class="pdp-user" src="/pdp_users/<?php echo $donnees['PDP']; ?>" alt="photo de profil">
					<?php echo "Par <b>".($donnees['PSEUDO'])."</b>" ?>
					</div>
					<div class="mess">
						<?php echo strip_tags($donnees['MESSAGES']); ?>
					</div>
					<div class="date">
					<?php $date = date_parse($donnees['DATE_MESSAGE']);
						$jour = $date['day'];
						$mois = $date['month'];
						$annee = $date['year'];
						$hours = $date['hour'];
						$minute = $date['minute'];
						if ($minute < 10) {
							$minute = '0'.$minute;
						}
						if ($mois < 10) {
							$mois = '0'.$mois;
                        }
                        if ($jour < 10) {
							$jour = '0'.$jour;
						}
						echo ' à '.$hours.':'.$minute." le ".$jour.'/'.$mois; ?>
					
					</div>
				</div>
				<?php } ?>
			</div>
					
		<!-- La boite de dialogue, pour rentrer le message-->
    	<div class="nav-mess">
				<form class="form-mess" action="post.php?channel=<?php echo $currentChannel; ?>" method="POST">
					<div class="form-in">
						<input type="text" name="message" placeholder="Ecrire un message...." maxlength="130" class="input" required>
						<button class="send" type="submit"><img class="send-i" src="/images/logo_mess.png"></button>
					</div>
				</form>
		</div>
		</div>
	</body>
</html>