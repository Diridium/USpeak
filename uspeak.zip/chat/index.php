<?php session_start();
if (!isset($_SESSION['login'])) {header('Location: /');}
include "../connect.php";

?>
<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8">
        <title>Mini-chat</title>
		<link rel="stylesheet" type="text/css" href="/style/template.css">
		<link rel="stylesheet" type="text/css" href="/style/chat.css">
    	<link rel="icon" type="image/png" href="/images/favicon.ico">
	</head>
    <body>

	<header>
		<img src="/images/logo.png" width="160px" height="auto" alt="img_logo" class="logo">
		<div style="color:white;">
			<p>Connecté avec</p>
			<div class="redtext"><a href="/profil/">
			<?php echo $_SESSION["pseudo"]; ?>
		</a></div>
		
		</div>
		<div>
			<p><a href="/chat/">Chat</a></p>
		</div>
		<div>
			<p><a href="/profil/">Mon Profil</a></p>
		</div>
		<div>
			<p><a href="/panel/">Panel</a></p>
		</div>
		<div>
			<p><a class="disco redtext" href="/disconnect.php">Se deconnecter</a></p>
		</div>
	</header>	

	<div class="mess-onglet-all">

		<?php
			if (isset($_GET['channel'])) { 
				$currentChannel = $_GET['channel']; 
				$checkChannel = $connect->query("SELECT NOM FROM channels WHERE NOM = '$currentChannel'");
				$checkChannel = $checkChannel->fetch();
				$checkChannel = $checkChannel['NOM'];
				if ($currentChannel == "") { ?>
					<div class="frame">
						<div class="errorframe">

							<!-- Nom du channel vide (indefini) -->

							<h2>Aucun channel choisi<br>
							Veuillez choisir un channel à droite dans l'onglet "Channels"</h2>

						</div>
					
					</div>

				<?php } elseif ($currentChannel == $checkChannel) { ?>
					<iframe class="frame" height="833x" src="only_chat.php<?php if (isset($_GET['channel'])) {echo "?channel=".$_GET['channel'];} ?>"></iframe>
				<?php } else { ?>
					<div class="frame">
						<div class="errorframe">

							<!-- Aucun channel choisi, cliquer à droite (get incorrect)-->

							<h2>Nom de channel incorrect<br>
							Veuillez choisir un channel à droite dans l'onglet "Channels"</h2>
						</div>

					</div>

				<?php }
			} else { ?>
				<div class="frame">
					<div class="homeframe">

						<!--Page d'arrivée (sans get)-->

						<h2>Bienvenue <?php echo $_SESSION["pseudo"]; ?>,<br>
						Pour commencer veuillez choisir un channel</h2>
					</div>

				</div>

			<?php } ?>
		
		<div class="onglet">
					<ul>
					<?php
						$chanels = $connect->query("SELECT * FROM channels");
						while ($donnees = $chanels->fetch()) { ?>
							<li><a href="?channel=<?php echo $donnees['NOM']; ?>"><span class="img-chan"><img src="/pdc_chan/<?php echo $donnees['PDC']; ?>" alt="logo channel"></span><span class="nom-chan"><?php echo $donnees['NOM']; ?></span></a></li>
							<br>
						<?php } ?>
					</ul>
		</div>
	</div>

</body>
</html>