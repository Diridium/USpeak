<?php
session_start();
if (!isset($_SESSION['login'])) {header('Location: /');}
include "../connect.php";

var_dump($_POST);
$btn = $_POST['btn'];
if ($btn == "Rename") {header("Location: rename_channel.php");}
else if ($btn == "ChangeDesc") {header("Location: change_desc.php");}
else if ($btn == "ChangePhoto") {header("Location: change_photo.php");}
else if ($btn == "SupprChan") {header("Location: delete_chan.php");}



if (isset($_POST['channels'])) {
    $channel = $_POST['channels'];
    $_SESSION['channel'] = "$channel";
} else {header("Location: channelconfig.php");};




?>